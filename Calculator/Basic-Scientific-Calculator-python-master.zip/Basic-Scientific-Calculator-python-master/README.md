# Basic-Scientific-Calculator-python
A scientific calculator using python with limited operations and functions

   This calculator has some basic trigonometric functions and arithmetic operations.
   All the trigonometric functions have been implemented using the "math" class.
